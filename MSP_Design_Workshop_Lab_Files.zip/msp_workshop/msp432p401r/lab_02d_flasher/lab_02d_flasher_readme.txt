As of Aug 2015, the MSP430Flasher command line utility doesn't support the MSP432, yet.

As an alternative, you may want to try out the UniFlasher tool for programming the MSP432 with
a binary file.