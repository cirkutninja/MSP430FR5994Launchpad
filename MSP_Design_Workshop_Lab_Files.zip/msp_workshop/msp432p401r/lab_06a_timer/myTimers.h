/*
 * myTimers.h
 *
 */

#ifndef MYTIMERS_H_
#define MYTIMERS_H_

// Prototypes
void initTimers(void);
void myTimer0_ISR (void);


#endif /* MYTIMERS_H_ */

