/*
 * myGPIO.h
 *
 */

#ifndef MYGPIO_H_
#define MYGPIO_H_

// Prototypes
void initGPIO(void);
void Port1_ISR(void);


#endif /* MYGPIO_H_ */

