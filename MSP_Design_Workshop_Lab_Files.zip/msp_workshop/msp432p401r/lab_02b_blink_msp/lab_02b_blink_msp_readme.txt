We plan to get into all the details of how GPIO (general purpose input/output) 
works in the next chapter. At that time, we will also introduce the MSPware 
DriverLib library to help you program GPIO, as well as all the other peripherals 
on the MSP devices.

In the lab exercise, we want to teach you a few additional debugging basics � 
and need some code to work with. To that end, we�re going to use the Blink 
template found in CCS. This is generic, low-level MSP code, but it should 
suite our purposes for now.
