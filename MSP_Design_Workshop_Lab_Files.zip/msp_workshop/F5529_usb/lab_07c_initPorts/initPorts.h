/*
 * initPorts.h
 */

#ifndef INITPORTS_H_
#define INITPORTS_H_

void initPorts(void);


#endif /* INITPORTS_H_ */
