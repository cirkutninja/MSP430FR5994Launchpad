lab_12

Since the 'F5529, 'FR5969, and MSP432P401R devices do not include the LCD peripheral, so there isn't a Lab 12 for these devices.
