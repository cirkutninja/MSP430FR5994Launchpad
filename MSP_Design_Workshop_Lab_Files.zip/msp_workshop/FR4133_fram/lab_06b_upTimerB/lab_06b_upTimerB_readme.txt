lab_06b_upTimerB

This is a variation of lab_06b_upTimer. The difference is the use of Timer_B 
rather than Timer_A.

Since the 'FR4133 doesn't include a Timer_B module, this optional exercise 
does not apply to this device.
