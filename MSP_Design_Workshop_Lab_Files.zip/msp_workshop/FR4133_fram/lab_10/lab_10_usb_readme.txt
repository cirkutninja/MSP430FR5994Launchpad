lab_10

Since the 'FR4133, 'FR5969, and 'FR6989 devices do not include a USB peripheral, there isn't a Lab_10 for these devices.
